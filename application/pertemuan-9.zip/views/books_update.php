<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">


<h1><?php echo $judul?></h1>

<!--$data_provinsi_single['id'] : perlu diletakan di url agar bisa diterima/tangkap pada controller (sbg penanda id yang akan diupdate) -->
<form method="post" action="<?php echo site_url('books/update_submit/'.$data_books_single['id_book']);?>">
	<table>
        <!--<tr>
            <td>Category</td>
            <td>
                <select name="id_category">
                    <?php //foreach ($data_books1 as $books):?>
                        <?php //if ($books['id_category'] == $data_books_single['category_name']) ?>
                    <option value="<?php //echo $data_books_single['id_category'];?>" selected><?php //echo $data_books_single['category_name'] ; ?></option>
                <?php //endforeach;?>
                </select>
            </td>
        </tr> -->
        <tr>
            <td>Category</td>
            <td>
                <select name="category">
                    <option value="<?php echo $data_books_single['category_name'];?>"><?php echo $data_books_single['category_name'] ; ?>
                    <?php 
                    foreach ($data_books1 as $data){
                        echo "<option value = '$data[id_category]'>$data[category_name]</option>";
                    }
                    ?>
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Publisher</td>
            <td>
                <select name="publisher">
                    <option value="<?php echo $data_books_single['publisher_name'];?>"><?php echo $data_books_single['publisher_name'] ; ?>
                    <?php 
                    foreach ($data_books2 as $data){
                        echo "<option value = '$data[id_publisher]'>$data[publisher_name]</option>";
                    }
                    ?>
                    </option>
                </select>
            </td>
        </tr>
		<tr>
			<td>Nama</td>
			<!--$data_provinsi_single['nama'] : menampilkan data provinsi yang dipilih dari database -->
			<td><input type="text" name="name" value="<?php echo $data_books_single['book_name'];?>" required=""></td>
		</tr>
        <tr>
            <td>Stock</td>
            <!--$data_provinsi_single['nama'] : menampilkan data provinsi yang dipilih dari database -->
            <td><input type="text" name="stock" value="<?php echo $data_books_single['book_stock'];?>" required=""></td>
        </tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type="submit" name="submit" value="Simpan"></td>
		</tr>
	</table>
</form>

</body>
</html>