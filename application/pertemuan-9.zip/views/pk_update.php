<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul?></title>
</head>
<body>

<h1><?php echo $judul?></h1>

<!--$data_provinsi_single['id'] : perlu diletakan di url agar bisa diterima/tangkap pada controller (sbg penanda id yang akan diupdate) -->
<form method="post" action="<?php echo site_url('pk/update_submit/'.$data_provinsi_single['id']);?>">
	<table>
		<tr>
			<td>Nama</td>
			<!--$data_provinsi_single['nama'] : menampilkan data provinsi yang dipilih dari database -->
			<td><select class="form-control" name="id">
				  <option disabled selected> Pilih </option>
                  <?php foreach($data_pk as $pk){ ?>
                  <option value="<?php echo $pk['id']; ?>"><?php echo $pk['nama_provinsi']; ?></option>
                  <?php } ?>
                  </select>
            </td>
		</tr>
		<tr>
			<td>Nama</td>
			<!--$data_provinsi_single['nama'] : menampilkan data provinsi yang dipilih dari database -->
			<td><input type="text" name="nama_provinsi" value="<?php echo $data_provinsi_single['nama_provinsi'];?>" required=""></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type="submit" name="submit" value="Simpan"></td>
		</tr>
	</table>
</form>

</body>
</html>
