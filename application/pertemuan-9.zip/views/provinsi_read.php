<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul?></title>
	 <style type="text/css">
        h1 {
            background-color: orange;
        }

        th {
        	background-color: lime;
        }
 
        td {
            background-color: purple;
        }
 
        option {
            background-color: green;
        }
    </style>
</head>
<body>

<h1><?php echo $judul?></h1>

<a href="<?php echo site_url('provinsi/insert');?>">Tambah</a>
<br /><br />

<table border="1">
	<thead>
		<tr>
			<th>Nama Provinsi</th>
			<!--<th>Nama Kota</th>
			<th>Populasi Penduduk</th>-->
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data_provinsi as $provinsi):?>
		<tr>
			<td><?php echo $provinsi['nama'];?></td>
			<!--<td><?php //echo $provinsi['nama_kota'];?></td>
			<td><?php //echo $provinsi['penduduk'];?></td>
			<td>
				<a href="<?php //echo site_url('provinsi/update/'.$provinsi['id_kota']);?>">
				Ubah
				</a>
				|
				<a href="<?php //echo site_url('provinsi/delete/'.$provinsi['id_kota']);?>">
				Hapus
				</a>
				|
				<a href="<?php //echo site_url('provinsi/export1/'.$provinsi['id_kota']);?>">
				Export
				</a>
			</td>-->
			<td>
				<a href="<?php echo site_url('provinsi/update/'.$provinsi['id']);?>">
				Ubah
				</a>
				|
				<a href="<?php echo site_url('provinsi/delete/'.$provinsi['id']);?>">
				Hapus
				</a>
				|
				<a href="<?php echo site_url('provinsi/export1/'.$provinsi['id']);?>">
				Export
				</a>
			</td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>
<a href="<?php echo site_url('provinsi/export');?>">Export</a>

</body>
</html>