<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul;?></title>
</head>
<body>

<h3><?php echo $judul;?></h3>

<h4>Tanda : <SPAN style="color:<?php echo $warna ?>"> <?php echo $tanda;?></SPAN></h4>

</body>
</html>