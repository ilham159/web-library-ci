<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul?></title>
</head>
<body>

<h1><?php echo $judul?></h1>

<a href="<?php echo site_url('pk/insert');?>">Tambah Provinsi Dan Kota</a>
<br /><br />

<table border="1">
	<thead>
		<tr>
			<th>Nama Provinsi</th>
			<th>Nama Kota</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data_pk as $pk):?>
		<tr>
			<td><?php echo $pk['nama'];?></td>
			<td><?php echo $pk['nama'];?></td>
			<td>
				<a href="<?php echo site_url('pk/update/'.$pk['id']);?>">
				Ubah
				</a>
				|
				<a href="<?php echo site_url('pk/delete/'.$pk['id']);?>">
				Hapus
				</a>
			</td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>

</body>
</html> 