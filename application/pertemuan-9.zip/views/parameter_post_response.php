<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul;?></title>
</head>
<body>

<h3><?php echo $judul;?></h3>

<ul>
	<li>Nama : <?php echo $post['nama'];?></li>
	<li>Umur : <?php echo $post['umur'];?></li>
	<?php
	$usia=$_POST['umur'];
	if ($usia<6)
	{
	   echo "<li>Anda Tergolong Balita</li>"; 
	}
	else if($usia<13)
	{
	   echo "<li>Anda Tergolong Anak</li>"; 
	}
	else if($usia<26)
	{
	   echo "<li>Anda Tergolong Remaja</li>"; 
	}
	else if($usia<51)
	{
	    echo "<li>Anda Tergolong Dewasa</li>"; 
	}
	else 
	{
	    echo "<li>Anda Tergolong Lansia</li>"; 
	}
	?>
</ul>

</body>
</html>