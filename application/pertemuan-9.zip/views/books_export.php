<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=export_data_books.xls" );
?>

<table border="1">
	<thead>
		<tr>
			<th>Books Name</th>
			<th>Category Name</th>
			<th>Publisher Name</th>
			<th>Stock</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($data_books as $books):?>
		<tr>
			<td><?php echo $books['book_name'];?></td>
			<td><?php echo $books['category_name'];?></td>
			<td><?php echo $books['publisher_name'];?></td>
			<td><?php echo $books['book_stock'];?></td>
		</tr>
		<?php endforeach?>		
	</tbody>
</table>