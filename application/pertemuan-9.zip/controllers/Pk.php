<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pk extends CI_Controller {

	public function __construct() {
        parent::__construct();

        //memanggil model
        $this->load->model('pk_model');
    }

	public function index() {
		//mengarahkan ke function read
		$this->read();
	}

	public function read() {
		//memanggil function read pada provinsi model
		//function read berfungsi mengambil/read data dari table provinsi di database
		$data_pk = $this->pk_model->read();

		//mengirim data ke view
		$output = array(
						'judul' => 'Daftar Provinsi Dan Kota',

						//data provinsi dikirim ke view
						'data_pk' => $data_pk
					);

		//memanggil file view
		$this->load->view('pk_read', $output);
	}

	public function insert() {
		$data_provinsi = $this->pk_model->read();
		//mengirim data ke view
		$output = array(
						'judul' => 'Tambah Provinsi dan kota',
					);

		//memanggil file view
		$this->load->view('pk_insert', $output);
	}

	public function insert_submit() {
		//menangkap data input dari view
		$id_provinsi = $this->input->post('id_provinsi');
		$nama_kota = $this->input->post('nama_kota');

		//mengirim data ke model
		$input = array(
						//format : nama field/kolom table => data input dari view
						'id_provinsi' => $id_provinsi,
						'nama_kota' => $nama_kota,
					);

		//memanggil function insert pada provinsi model
		//function insert berfungsi menyimpan/create data ke table provinsi di database
		$data_pk = $this->pk_model->insert($input);

		//mengembalikan halaman ke function read
		redirect('pk/read');
	}

	public function update() {
		//menangkap id data yg dipilih dari view (parameter get)
		$id = $this->uri->segment(3);

		//function read berfungsi mengambil 1 data dari table provinsi sesuai id yg dipilih
		$data_provinsi_single = $this->pk_model->read_single($id);

		//mengirim data ke view
		$output = array(
						'judul' => 'Tambah Provinsi dan kota',

						//mengirim data provinsi yang dipilih ke view
						'data_provinsi_single' => $data_provinsi_single,
					);

		//memanggil file view
		$this->load->view('pk_update', $output);
	}

	public function update_submit() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//menangkap data input dari view
		$nama_provinsi = $this->input->post('nama_provinsi');

		//mengirim data ke model
		$input = array(
						//format : nama field/kolom table => data input dari view
						'nama_provinsi' => $nama_provinsi,
					);

		//memanggil function insert pada provinsi model
		//function insert berfungsi menyimpan/create data ke table provinsi di database
		$data_pk = $this->pk_model->update($input, $id);

		//mengembalikan halaman ke function read
		redirect('pk/read');
	}

	public function delete() {
		//menangkap id data yg dipilih dari view
		$id = $this->uri->segment(3);

		//memanggil function delete pada provinsi model
		$data_pk = $this->pk_model->delete($id);

		//mengembalikan halaman ke function read
		redirect('pk/read');
	}
}