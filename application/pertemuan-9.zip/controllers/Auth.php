<?php
defined('BASEPATH') or exit('No dirrect script access allowed');

/**
  * 
  */
 class Auth extends CI_Controller
 {
 	public function __construct() {
        parent::__construct();

        //memanggil model
        $this->load->library('form_validation');
    }
 	
 	public function index()
 	{
 		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
 		$this->form_validation->set_rules('password', 'Password', 'trim|required');
 		if ($this->form_validation->run() == false) {
 		//mengirim data ke view
		$output = array(
						'judul' => 'Login',
						//mengirim daftar provinsi ke view,
					);

		//memanggil file view
 		$this->load->view('login/login_header', $output);
 		$this->load->view('login/login');
 		$this->load->view('login/login_footer');

 		} else {
 			#validation success
 			$this->login();
 		}
 	}

 	private function login()
 	{
 		$email = $this->input->post('email');
 		$password = $this->input->post('password');

 		$user = $this->db->get_where('user', ['email' => $email])->row_array();

 		#if there's user
 		if ($user) {
 			if ($user['is_active'] == 1) {
 				#cek password
 				if (password_verify($password, $user['password'])) {
 					$input = [
 						'email' => $user['email'],
 						'role' => $user['role_id']
 					];
 					$this->session->set_userdata($input);
 					redirect('Books/dashboard');
 				} else {
 					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
 					Warning! The password you entered is wrong. please check again!
 					</div>');
 					redirect('auth');
 				}
 			} else {
 				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
	  			Warning! This email has not been activated. please activated now!
				</div>');
				redirect('auth');
 			}

 		} else {
 			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
  			Warning! The email you entered is not registered. please register now!
			</div>');
			redirect('auth');
 		}
 	}

 	public function register()
 	{
 		$this->form_validation->set_rules('username', 'Username', 'required|trim');
 		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
 			'is_unique' => 'This email has already registered!'

 		]);
 		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[8]|matches[password2]',[
 			'matches' => 'password dont match!',
 			'min_length' => 'password too short!'
 		]);
 		$this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');
 		if ($this->form_validation->run() == false) {
 			//mengirim data ke view
			$output = array(
							'judul' => 'Register',
							//mengirim daftar provinsi ke view,
						);

			//memanggil file view
	 		$this->load->view('login/login_header', $output);
	 		$this->load->view('login/register');
	 		$this->load->view('login/login_footer');
 		} else{
 			$username =htmlspecialchars($this->input->post('username', true));
 			$email = htmlspecialchars($this->input->post('email', true));
 			$password = password_hash($this->input->post('password1'), PASSWORD_DEFAULT);
 			$image = 'default.jpg';
 			$role_id = '2';
 			$is_active = '1';
 			$date_created = time();
 			$input = array (
 				'username' => $username,
 				'email' => $email,
 				'image' => $image,
 				'password' => $password,
 				'role_id' => $role_id,
 				'is_active' => $is_active,
 				'date_created' => $date_created,
 			);

 			$this->db->insert('user', $input);
 			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
  			Success! your account has been created. please login
			</div>');
 			redirect('auth');
 		}
 	}

 	public function logout()
 	{
 		$this->session->unset_userdata('email');
 		$this->session->unset_userdata('role_id');

 		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
  		Success! you have been logout.
		</div>');
 		redirect('auth');
 	}
 } 
